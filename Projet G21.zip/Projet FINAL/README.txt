Comme nous sommes deux dans notre groupe, nous avons procédé comme suit:
-Partie JAVA développé par Lucas GIRARD
-Partie en C Développé par Mehdi OUZAA

Note sur le code en JAVA:
J'ai tout fais cependant il,y a un bug lors de la conversion en json qui est très probablement 
due a la version de java que j'utilise. cela empêche donc de lire les fichier JSON .